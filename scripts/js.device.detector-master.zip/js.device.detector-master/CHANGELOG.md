# Change Log

## 1.0.1
* fix potential security vulnerability found in the serve dependency

## 1.0.0
### Feature
Add jQuery Plugin:
* Detect Browser and Device Information
* Detect Supported Devices and Browser by Browser Matrix
* Detect mobile Browser
* Detect desktop Browser
* Detect Chrome, Firefox, MSIE, Edge, Safari, ieMobile and Opera Browser
* Detect Windows, Linux/BSD/Unix and Mac OS Desktop Operating Systems
* Detect Windows Phone, Windows Mobile, iOS, Android and BlackBerry mobile Operating Systems
* Detect Major, Minor and Bugfix OS Version
* Detect Major Browser Version
* Configure own Browser Matrix and Information
